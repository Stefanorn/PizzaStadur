//
//  SuperHero.hpp
//  Verkefni1.b.i
//
//  Created by Stefan Orn Hrafnsson on 27/11/2017.
//  Copyright � 2017 Stefan Orn Hrafnsson. All rights reserved.
//

#ifndef SuperHero_h
#define SuperHero_h

#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class SuperHero{

public:
    SuperHero();
    // Defult smi�ur
    //SuperHero(string name, int age, char power);
    // Smi�ur sem tekur inn 3 f�ribreytur
    void WriteToFile(string path, SuperHero& hero) const;
    // Til a� skrifa hetjur � skr�
    //int CountLines(ifstream in, int num, string str);
    friend istream& operator >> (istream& in, SuperHero& sh);
    friend ostream& operator << (ostream& out, SuperHero& sh);

private:
    string _name;
    int _age;
    char _power;
    string readPower(char icon);
    // Til a� breyta power �r char i string
};

#endif /* SuperHero_h */
