//
//  main.cpp
//  Verkefni1.b.i
//
//  Created by Stefan Orn Hrafnsson on 27/11/2017.
//  Copyright � 2017 Stefan Orn Hrafnsson. All rights reserved.
//

#include <iostream>
#include "SuperHero.h"

int main() {
    SuperHero hero;
    ifstream in;
    char input;
    do
    {
        cout << "Press 1 to create a new superhero" << endl
        << "Press 2 to print out all existing heroes" << endl
        << "Press q or Q to quit " << endl;
        cin >> input;
        if (input == '1')
        {
            hero.WriteToFile("SuperHeroes.txt", hero);
        }

        else if (input == '2')
        {
            in.open("SuperHeroes.txt");
            if (in.is_open())
            {
                //string name, age, heropower;
                while(in >> hero)
                {
                    cout << hero << endl;
                    /*
                    in >> age;
                    in >> heropower;
                    cout << "Name: " << name << endl;
                    cout << "Age: " << age << endl;
                    cout << "Power: " << heropower << endl;*/
                }
                /*
                string dump;
                int num = 0;
                while(!in.eof())
                {
                    getline(in, dump);
                    num++;
                }
                in.close();
                num = num / 3;

                in.open("SuperHeroes.txt");

                for(int i = 0; i < num; i++)
                {
                    in >> hero;
                    cout << hero << endl;
                    in.close();
                }*/
                in.close();
            }
            else
            {
                cout << "Unable to read from file!" << endl;
            }
        }
    }
    while (input != 'q' && input != 'Q');

    return 0;
}
