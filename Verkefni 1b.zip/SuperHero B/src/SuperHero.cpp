//
//  SuperHero.cpp
//  Verkefni1.b.i
//
//  Created by Stefan Orn Hrafnsson on 27/11/2017.
//  Copyright � 2017 Stefan Orn Hrafnsson. All rights reserved.
//

#include "SuperHero.h"

///// Public f�ll /////
SuperHero::SuperHero(){
    _name = "";
    _power = 'n';
    _age = 0;
}

/*SuperHero::SuperHero(string name, int age, char power){
    _name = name;
    _age = age;
    _power = power;

}*/

void SuperHero::WriteToFile(string path, SuperHero& hero) const {
    ofstream out;
    out.open("SuperHeroes.txt", ios::app);
    cin >> hero;
    out << _name << endl;
    out << _age << endl;
    out << _power << endl;
    out.close();
}

/*int CountLines(int num, string str)
{
    in.open();
    while(!in.eof())
    {
        getline(in, dump);
        num++;
    }
    in.close();
    num = num / 3;

    return num/3;
}*/

///// Friend F�ll /////

istream& operator >> (istream& in, SuperHero& sh){
    if (in == cin)
    {
        cout << "Name: ";
    }
    in >> sh._name;
    if (in == cin)
    {
        cout << "Age: ";
    }
    in >> sh._age;
    if (in == cin)
    {
        cout << "Power (f, g, h, n): ";
    }
    in >> sh._power;

    return in;
}

ostream& operator << (ostream& out, SuperHero& sh)
{
    out << "Name: " << sh._name << endl;
    out << "Age: " << sh._age << endl;
    out << "Power: " << sh.readPower(sh._power) << endl;

    return out;
}

////////// Private f�ll //////

string SuperHero::readPower(char icon){
    switch (icon) {
        case 'f':
            return "Flying";
            break;
        case 'g':
            return "Giant";
            break;
        case 'h':
            return "Hacker";
            break;
        case 'n':
            return "None";
            break;
        default:
            return "Weakling";
            break;
    }
}
