#ifndef SuperHero_h
#define SuperHero_h

#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class SuperHero{

public:
    SuperHero();
    // Defult smi�ur
    friend istream& operator >> (istream& in, SuperHero& sh);
    friend ostream& operator << (ostream& out, SuperHero& sh);

private:
    char _name[16];
    int _age;
    char _power;
    string readPower(char icon);
    // Til a� breyta power �r char i string
};

#endif /* SuperHero_h */
