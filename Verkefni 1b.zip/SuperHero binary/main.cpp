#include "SuperHero.h"

int main() {
    SuperHero* hero;
    ifstream in;
    ofstream out;
    char input;
    int size = 0;
    do
    {
        cout << "Press 1 to create a new superhero" << endl
        << "Press 2 to print out all existing heroes" << endl
        << "Press q or Q to quit " << endl;
        cin >> input;
        if (input == '1')
        {
            cout << "How many heroes would you like to create? ";
            cin >> size;
            hero = new SuperHero[size];
            for(int i = 0; i < size; i++)
            {
                cin >> hero[i];
            }

            out.open("Binary Heroes.dat", ios::binary|ios::app);

            out.write((char*)(hero), sizeof(SuperHero)* size);
            out.close();
        }

        else if (input == '2')
        {
            in.open("Binary Heroes.dat", ios::binary);

            in.seekg(0, in.end);
            int arraySize = in.tellg() / sizeof(SuperHero);
            in.seekg(0, in.beg);

            SuperHero temp;
            hero = new SuperHero[arraySize];
            for(int i = 0; i < arraySize; i++)
            {
                in.read((char*)(&temp), sizeof(SuperHero));
                hero[i] = temp;
                cout << hero[i] << endl;
            }
            in.close();
        }
    }
    while (input != 'q' && input != 'Q');

    return 0;
}
