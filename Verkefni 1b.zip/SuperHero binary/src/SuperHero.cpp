#include "SuperHero.h"

///// Public f�ll /////
SuperHero::SuperHero(){
    _name[0] = '\0';
    _power = 'n';
    _age = 0;
}

///// Friend F�ll /////

istream& operator >> (istream& in, SuperHero& sh){
    if (in == cin)
    {
        cout << "Name: ";
    }
    in >> sh._name;
    if (in == cin)
    {
        cout << "Age: ";
    }
    in >> sh._age;
    if (in == cin)
    {
        cout << "Power (f, g, h, n): ";
    }
    in >> sh._power;

    return in;
}

ostream& operator << (ostream& out, SuperHero& sh)
{
    out << "Name: " << sh._name << endl;
    out << "Age: " << sh._age << endl;
    out << "Power: " << sh.readPower(sh._power) << endl;

    return out;
}

////////// Private f�ll //////

string SuperHero::readPower(char icon){
    switch (icon) {
        case 'f':
            return "Flying";
            break;
        case 'g':
            return "Giant";
            break;
        case 'h':
            return "Hacker";
            break;
        case 'n':
            return "None";
            break;
        default:
            return "Weakling";
            break;
    }
}
